-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: kahootdatabase
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fragen`
--

DROP TABLE IF EXISTS `fragen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fragen` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `FragebogenID` int NOT NULL,
  `Fragestellung` text NOT NULL,
  `Antwort1` text NOT NULL,
  `IstAntwort1Richtig` tinyint(1) DEFAULT NULL,
  `Antwort2` text NOT NULL,
  `IstAntwort2Richtig` tinyint(1) DEFAULT NULL,
  `Antwort3` text NOT NULL,
  `IstAntwort3Richtig` tinyint(1) DEFAULT NULL,
  `Antwort4` text NOT NULL,
  `IstAntwort4Richtig` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  CONSTRAINT `chk_mindestens_eine_richtig` CHECK (((`IstAntwort1Richtig` = 1) or (`IstAntwort2Richtig` = 1) or (`IstAntwort3Richtig` = 1) or (`IstAntwort4Richtig` = 1)))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fragen`
--

LOCK TABLES `fragen` WRITE;
/*!40000 ALTER TABLE `fragen` DISABLE KEYS */;
INSERT INTO `fragen` VALUES (16,6295,'Auto','Mercedes',1,'Audi',0,'Skoda',0,'Opel',0),(17,6295,'Essen','Pizza',0,'Pasta',1,'Döner',0,'Brot',0),(18,6295,'Sport','Fußball',0,'Eishockey',0,'Tennis',1,'Golf',0),(19,6295,'Beruf','Lehrer',0,'Sportler',0,'Finanzberater',0,'Bänker',1),(20,6441,'Größtes Land ','Saudi Arabien',0,'Russland ',1,'DEutschland ',0,'Schweiz',0),(21,6441,'Größster Fluss','Niel',1,'Donau',0,'Lech',0,'Blau',0),(22,1824,'Deutschland','München',0,'Berlin',1,'Stuttgart',0,'Hessen',0),(23,1824,'USA ','LA',0,'Bosten',0,'NYC',0,'Washington DC',1),(24,1824,'Polen','Warschau',1,'Prkay',0,'Brag',0,'Swabr',0),(25,1824,'Schweden','Hööwen',0,'Oslo',1,'Beuded',0,'Brame',0),(31,8516,'Was sind Bohrer ','Maschinen ',1,'Birne',0,'Äpfel',0,'Traube',0),(32,8516,'Was ist nicht wichtig im Umspannwerk ','Sonnenbrille',1,'Helm ',0,'Stahlkappenschuhe',0,'Warnweste',0),(33,8516,'Warum sind Handwerker wichtig ','Sind nicht wichtig ',0,'Weil Handwerker',0,'Einfach so ',1,'Weil Schlau',0);
/*!40000 ALTER TABLE `fragen` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-31 23:09:29
