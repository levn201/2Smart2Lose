-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: kahootdatabase
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aspnetusers`
--

DROP TABLE IF EXISTS `aspnetusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aspnetusers` (
  `Id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `UserName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `NormalizedUserName` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Email` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `NormalizedEmail` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `EmailConfirmed` tinyint(1) NOT NULL,
  `PasswordHash` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `SecurityStamp` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ConcurrencyStamp` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PhoneNumber` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `PhoneNumberConfirmed` tinyint(1) NOT NULL,
  `TwoFactorEnabled` tinyint(1) NOT NULL,
  `LockoutEnd` datetime(6) DEFAULT NULL,
  `LockoutEnabled` tinyint(1) NOT NULL,
  `AccessFailedCount` int NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UserNameIndex` (`NormalizedUserName`),
  KEY `EmailIndex` (`NormalizedEmail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aspnetusers`
--

LOCK TABLES `aspnetusers` WRITE;
/*!40000 ALTER TABLE `aspnetusers` DISABLE KEYS */;
INSERT INTO `aspnetusers` VALUES ('22e048ee-9242-4777-9ad7-1b076077bfd4','l.barth@transnetbw.de','L.BARTH@TRANSNETBW.DE','l.barth@transnetbw.de','L.BARTH@TRANSNETBW.DE',0,'AQAAAAIAAYagAAAAEAE/q7JVAKhjtDqiHP+g7BsWdTeuGHd5B6HtVXwRNa95kFrTFldKBQ1QUsRUv0m0/A==','5TK7COY62AZDEIGBKBGSMZGFO6FRO7LL','ebd112b4-6dd7-44d2-8321-f60112f9851d',NULL,0,0,NULL,1,0),('440c9876-1137-4b40-b1a4-7320b1a90450','l.tokdemir@transnetbw.de','L.TOKDEMIR@TRANSNETBW.DE','l.tokdemir@transnetbw.de','L.TOKDEMIR@TRANSNETBW.DE',0,'AQAAAAIAAYagAAAAEI9/GM4FVhg5+Xgc819YNkkKU19saVH/8dMAVjAPq55DsjRsoQVSLxLPM02mBNn78w==','VSDAAOGTG4DNQXSZQ6TH4Q7YVWZFVVK7','9aca8d99-d022-4f10-bc8f-b8a091b56b79',NULL,0,0,NULL,1,0),('5500715d-013f-407e-9def-0f81b3b94325','elevinevien@transne.de','ELEVINEVIEN@TRANSNE.DE','elevinevien@transne.de','ELEVINEVIEN@TRANSNE.DE',0,'AQAAAAIAAYagAAAAEIGWbZtlHPA9eeMOEDL4/A16aEMFp5WMgNljuRkg7Q6PlVsfyVK9uaXaBZoBKMw67w==','MRKTGTHN6UQJ4ERO6MZOCAP7RLCEHPLU','47157d33-284f-47be-a30c-8870f64f6f8e',NULL,0,0,NULL,1,0),('7d2821c1-ef44-40bd-b2b8-282b6e3a79ae','b.lorenz@transnetbw.de','B.LORENZ@TRANSNETBW.DE','b.lorenz@transnetbw.de','B.LORENZ@TRANSNETBW.DE',0,'AQAAAAIAAYagAAAAEODWXULnj7zAhiqbs6DUWqo2Dvbh0s+Fvq+LfoMaUltl8C2AXX7RFvw8KbZwwcOzlQ==','MT77AIARRP5WKTU4AFCAPFALSR52UYVY','afde976f-1e60-43df-a170-965b942cb124',NULL,0,0,NULL,1,0),('918a4273-fe29-45c0-89e0-595a1f1639b4','f.hinterser@transnetbw.de','F.HINTERSER@TRANSNETBW.DE','f.hinterser@transnetbw.de','F.HINTERSER@TRANSNETBW.DE',0,'AQAAAAIAAYagAAAAEM+f9yXjSkNmgmQgJ74Szky6r4jJbxZigHMJJ3gRCsqIUJlYonUkHBiobFgg4K9fug==','PXM6E5KUFVQV74TCFYUS2WZKGACIC7L5','9cb226a2-d5c2-4d31-9f4e-e69a3de143cd',NULL,0,0,NULL,1,0),('a724bc0b-460f-4cf1-813d-e29857479030','admin@smart2lose.com','ADMIN@SMART2LOSE.COM','admin@smart2lose.com','ADMIN@SMART2LOSE.COM',1,'AQAAAAIAAYagAAAAEOhR90ZGitWogkzZetPNT+PrrHDr3IN5nMipwyBuWX7CqS1OvW4N/ssXudb4OzezNg==','OPHYVOVCL6UIXJ4TADIWWNLKOLU7KXBU','4918e619-1336-43f0-81e9-b0f19f910d80',NULL,0,0,NULL,1,0);
/*!40000 ALTER TABLE `aspnetusers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-31 23:09:29
